package com.samsung.common;

public class CommonVO {

}
